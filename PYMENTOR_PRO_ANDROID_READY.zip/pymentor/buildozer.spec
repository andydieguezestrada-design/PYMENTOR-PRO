[app]

title = PYMENTOR PRO
package.name = pymentorpro
package.domain = org.pymentorpro

source.dir = .
source.include_exts = py,kv,json,txt,png,jpg,jpeg,atlas,ttf

version = 1.0.0

requirements = python3,kivy==2.3.1

orientation = portrait
fullscreen = 0

android.api = 35
android.minapi = 24
android.ndk = 28c
android.ndk_api = 24
android.accept_sdk_license = True

android.archs = arm64-v8a,armeabi-v7a

android.permissions = INTERNET

presplash.filename = %(source.dir)s/assets/images/presplash.png
icon.filename = %(source.dir)s/assets/icons/icon.png

[buildozer]

log_level = 2
warn_on_root = 1
