from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.progressbar import ProgressBar
from kivy.uix.scrollview import ScrollView
from kivy.uix.widget import Widget
from kivy.app import App
from screens.base import BaseScreenMixin, NavBar, label, button, CARD, MUTED, TEXT, ACCENT


class HomeScreen(BaseScreenMixin, __import__("kivy.uix.screenmanager", fromlist=["Screen"]).Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build()

    def build(self):
        root = self.shell("PYMENTOR PRO", "Tu camino para dominar Python")
        scroll = ScrollView()
        content = BoxLayout(orientation="vertical", spacing=dp(12), size_hint_y=None, padding=(0, 0, 0, dp(8)))
        content.bind(minimum_height=content.setter("height"))

        self.progress_label = label("", 16, TEXT, True, size_hint_y=None, height=dp(30))
        content.add_widget(self.progress_label)
        self.progress_bar = ProgressBar(max=100, value=0, size_hint_y=None, height=dp(8))
        content.add_widget(self.progress_bar)
        self.level_label = label("", 12, MUTED, size_hint_y=None, height=dp(28))
        content.add_widget(self.level_label)

        card = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(8),
                         size_hint_y=None, height=dp(150))
        self.next_title = label("", 18, TEXT, True)
        self.next_sub = label("", 12, MUTED)
        card.add_widget(label("CONTINUAR APRENDIENDO", 11, ACCENT, True))
        card.add_widget(self.next_title)
        card.add_widget(self.next_sub)
        card.add_widget(button("CONTINUAR", lambda *_: self.continue_learning(), True))
        content.add_widget(card)

        challenge = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(7),
                              size_hint_y=None, height=dp(125))
        challenge.add_widget(label("⚡ RETO DEL DÍA", 11, ACCENT, True))
        challenge.add_widget(label("Segundo número más grande", 17, TEXT, True))
        challenge.add_widget(label("+100 XP  •  10 min", 12, MUTED))
        challenge.add_widget(button("COMENZAR", lambda *_: App.get_running_app().go("challenges")))
        content.add_widget(challenge)

        mentor = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(7),
                           size_hint_y=None, height=dp(120))
        mentor.add_widget(label("MENTOR IA OFFLINE", 11, ACCENT, True))
        mentor.add_widget(label("Pregunta, aprende y recibe orientación.", 15, TEXT, True))
        mentor.add_widget(button("ABRIR MENTOR", lambda *_: App.get_running_app().go("mentor"), True))
        content.add_widget(mentor)

        scroll.add_widget(content)
        root.add_widget(scroll)
        root.add_widget(NavBar())
        self.add_widget(root)

    def refresh(self):
        app = App.get_running_app()
        p = app.progress.profile()
        stats = app.db.stats()
        pct = app.progress.progress_percent()
        self.progress_label.text = f"PROGRESO   {pct}%"
        self.progress_bar.value = pct
        self.level_label.text = f"{app.progress.title_for_xp(p['xp'])}   •   {p['xp']} XP   •   Racha {p['streak']} días"
        lesson = app.curriculum.first_uncompleted(app.db)
        self.next_title.text = lesson["title"]
        self.next_sub.text = f"{lesson['level'].upper()}  •  {lesson['position']} · Lección"

    def continue_learning(self):
        App.get_running_app().go("learn")
