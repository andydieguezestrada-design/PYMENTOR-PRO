from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import Screen
from screens.base import BaseScreenMixin, NavBar, label, button, MUTED, TEXT, ACCENT


class ProgressScreen(BaseScreenMixin, Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build()

    def build(self):
        root = self.shell("PROGRESO", "Tu evolución como programador")
        scroll = ScrollView()
        self.content = BoxLayout(orientation="vertical", spacing=dp(12), size_hint_y=None, padding=dp(6))
        self.content.bind(minimum_height=self.content.setter("height"))
        scroll.add_widget(self.content)
        root.add_widget(scroll)
        root.add_widget(NavBar())
        self.add_widget(root)

    def refresh(self):
        app = App.get_running_app()
        p = app.progress.profile()
        s = app.db.stats()
        pct = app.progress.progress_percent()
        self.content.clear_widgets()
        rows = [
            ("PYTHON LEVEL", f"{app.progress.title_for_xp(p['xp'])}"),
            ("PROGRESO", f"{pct}%"),
            ("LECCIONES", f"{s['completed_lessons']} / {s['total_lessons']}"),
            ("EJERCICIOS", str(s["attempts"])),
            ("XP", f"{p['xp']} XP"),
            ("RACHA", f"{p['streak']} días"),
            ("RECOMENDACIÓN", app.progress.recommendation()),
        ]
        for title, value in rows:
            self.content.add_widget(label(f"{title}\n{value}", 15, ACCENT if title in ("XP", "PYTHON LEVEL") else TEXT,
                                          True, size_hint_y=None, height=dp(72)))
