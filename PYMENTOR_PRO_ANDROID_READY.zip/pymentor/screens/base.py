from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label


BG = (0.035, 0.043, 0.07, 1)
CARD = (0.075, 0.09, 0.14, 1)
TEXT = (0.92, 0.95, 1, 1)
MUTED = (0.57, 0.63, 0.74, 1)
ACCENT = (0.2, 0.72, 1, 1)
SUCCESS = (0.25, 0.85, 0.56, 1)


def label(text="", size=16, color=TEXT, bold=False, **kwargs):
    return Label(text=text, font_size=sp(size), color=color,
                 bold=bold, halign="left", valign="middle", **kwargs)


def sp(value):
    return dp(value)


def button(text, callback, accent=False):
    b = Button(text=text, size_hint_y=None, height=dp(48),
               background_normal="", background_color=ACCENT if accent else CARD,
               color=BG if accent else TEXT, font_size=dp(14), bold=True)
    b.bind(on_release=callback)
    return b


class NavBar(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="horizontal", size_hint_y=None, height=dp(62),
                         spacing=dp(5), padding=dp(5), **kwargs)
        items = [("⌂  Inicio", "home"), ("▣  Aprender", "learn"),
                 ("◉  Mentor", "mentor"), ("⚡  Retos", "challenges"),
                 ("◈  Progreso", "progress")]
        for text, target in items:
            b = Button(text=text, background_normal="", background_color=CARD,
                       color=TEXT, font_size=dp(11))
            b.bind(on_release=lambda _, t=target: App.get_running_app().go(t))
            self.add_widget(b)


class BaseScreenMixin:
    def shell(self, title, subtitle=None):
        root = BoxLayout(orientation="vertical", padding=dp(14), spacing=dp(10))
        header = BoxLayout(size_hint_y=None, height=dp(68), spacing=dp(8))
        title_box = BoxLayout(orientation="vertical")
        title_box.add_widget(label(title, 23, TEXT, True))
        if subtitle:
            title_box.add_widget(label(subtitle, 11, MUTED))
        header.add_widget(title_box)
        settings = Button(text="⚙", size_hint_x=None, width=dp(48),
                          background_normal="", background_color=CARD, color=TEXT,
                          font_size=dp(20))
        settings.bind(on_release=lambda *_: App.get_running_app().go("settings"))
        header.add_widget(settings)
        root.add_widget(header)
        return root
