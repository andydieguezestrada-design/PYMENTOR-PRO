import json
from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import Screen
from kivy.uix.textinput import TextInput
from screens.base import BaseScreenMixin, NavBar, label, button, CARD, MUTED, TEXT, ACCENT


class ChallengesScreen(BaseScreenMixin, Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.index = 0
        self.build()

    def build(self):
        root = self.shell("⚡ RETOS", "Practica con problemas progresivos")
        scroll = ScrollView()
        self.content = BoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None)
        self.content.bind(minimum_height=self.content.setter("height"))
        scroll.add_widget(self.content)
        root.add_widget(scroll)
        root.add_widget(NavBar())
        self.add_widget(root)

    def refresh(self):
        app = App.get_running_app()
        self.challenges = app.curriculum.challenges
        self.render()

    def render(self):
        if not self.challenges:
            return
        app = App.get_running_app()
        c = self.challenges[self.index % len(self.challenges)]
        self.content.clear_widgets()
        self.content.add_widget(label(c["title"], 23, TEXT, True, size_hint_y=None, height=dp(48)))
        self.content.add_widget(label(f"{c['difficulty'].upper()}   •   +{c['xp']} XP   •   {c['time']}", 12, ACCENT, True,
                                      size_hint_y=None, height=dp(35)))
        self.content.add_widget(label(c["description"], 15, TEXT, size_hint_y=None, height=dp(90)))
        self.content.add_widget(label("PISTAS\n" + "\n".join("• " + x for x in c["hints"]), 13, MUTED,
                                      size_hint_y=None, height=dp(120)))
        answer = TextInput(hint_text="Escribe aquí tu solución Python…", multiline=True,
                           size_hint_y=None, height=dp(190), background_color=CARD,
                           foreground_color=TEXT, hint_text_color=MUTED, padding=dp(12))
        self.content.add_widget(answer)
        self.content.add_widget(button("ANALIZAR SOLUCIÓN", lambda *_: self.evaluate(c, answer.text), True))
        self.content.add_widget(label("SOLUCIÓN DE REFERENCIA\n" + c["solution"], 13, TEXT,
                                      size_hint_y=None, height=dp(210)))
        self.content.add_widget(button("SIGUIENTE RETO", lambda *_: self.next(), False))

    def evaluate(self, challenge, answer):
        app = App.get_running_app()
        from core.evaluator import CodeEvaluator
        result = CodeEvaluator().analyze(answer)
        if result["ok"]:
            app.progress.record_exercise("challenge:" + challenge["id"], answer, 100, result["message"])
            app.progress.award(challenge["xp"])
        self.render()
        app.refresh_all()

    def next(self):
        self.index += 1
        self.render()
