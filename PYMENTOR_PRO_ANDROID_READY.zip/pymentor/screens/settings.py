from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.screenmanager import Screen
from kivy.uix.spinner import Spinner
from screens.base import BaseScreenMixin, label, button, CARD, MUTED, TEXT, ACCENT


class SettingsScreen(BaseScreenMixin, Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build()

    def build(self):
        root = self.shell("CONFIGURACIÓN", "Personaliza tu ruta de aprendizaje")
        body = BoxLayout(orientation="vertical", spacing=dp(10))
        body.add_widget(label("NIVEL INICIAL", 12, ACCENT, True, size_hint_y=None, height=dp(30)))
        self.level = Spinner(text="Principiante", values=("Principiante", "Intermedio", "Avanzado"),
                             size_hint_y=None, height=dp(48), background_color=CARD, color=TEXT)
        body.add_widget(self.level)
        body.add_widget(label("OBJETIVO", 12, ACCENT, True, size_hint_y=None, height=dp(30)))
        self.goal = Spinner(text="Aprender desde cero",
                            values=("Aprender desde cero", "Conseguir trabajo", "Automatizar tareas",
                                    "Crear aplicaciones", "Data Science", "IA / Machine Learning",
                                    "Backend", "Ciberseguridad", "Desarrollo profesional"),
                            size_hint_y=None, height=dp(48), background_color=CARD, color=TEXT)
        body.add_widget(self.goal)
        body.add_widget(button("GUARDAR PREFERENCIAS", self.save, True))
        body.add_widget(button("BORRAR HISTORIAL DEL MENTOR", self.clear_history))
        body.add_widget(label(
            "PYMENTOR PRO funciona offline para el currículo, ejercicios y progreso. "
            "El mentor local usa una base de conocimientos y análisis estático. "
            "La arquitectura permite añadir un proveedor de IA remoto sin guardar API keys en el código.",
            12, MUTED, size_hint_y=None, height=dp(130)
        ))
        root.add_widget(body)
        self.add_widget(root)

    def refresh(self):
        p = App.get_running_app().progress.profile()
        self.level.text = {"beginner":"Principiante","intermediate":"Intermedio","advanced":"Avanzado"}.get(p["level"], "Principiante")

    def save(self, *_):
        app = App.get_running_app()
        mapping = {"Principiante":"beginner", "Intermedio":"intermediate", "Avanzado":"advanced"}
        app.db.update_profile(level=mapping[self.level.text], goal=self.goal.text)

    def clear_history(self, *_):
        App.get_running_app().db.clear_history()
