from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import Screen
from kivy.uix.textinput import TextInput
from screens.base import BaseScreenMixin, NavBar, label, button, CARD, MUTED, TEXT, ACCENT


class MentorScreen(BaseScreenMixin, Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.build()

    def build(self):
        root = self.shell("MENTOR IA", "Profesor particular offline de Python")
        scroll = ScrollView()
        self.history = BoxLayout(orientation="vertical", spacing=dp(9), size_hint_y=None, padding=dp(4))
        self.history.bind(minimum_height=self.history.setter("height"))
        scroll.add_widget(self.history)
        root.add_widget(scroll)

        self.input = TextInput(hint_text="Pregunta o pega código Python…", multiline=True,
                               size_hint_y=None, height=dp(105),
                               background_color=CARD, foreground_color=TEXT,
                               hint_text_color=MUTED, padding=dp(12))
        root.add_widget(self.input)
        send = button("ENVIAR AL MENTOR", self.send, True)
        root.add_widget(send)
        root.add_widget(NavBar())
        self.add_widget(root)

    def refresh(self):
        app = App.get_running_app()
        self.history.clear_widgets()
        rows = list(reversed(app.db.mentor_messages(40)))
        if not rows:
            self.add_message("mentor", "Hola. Soy tu mentor offline. Pregúntame cualquier cosa sobre Python.")
        for row in rows:
            self.add_message(row["role"], row["message"])

    def add_message(self, role, text):
        prefix = "TÚ" if role == "user" else "MENTOR"
        color = ACCENT if role == "user" else TEXT
        self.history.add_widget(label(f"{prefix}\n{text}", 13, color,
                                      role != "user", size_hint_y=None,
                                      height=dp(max(62, 24 + text.count("\n")*19))))

    def send(self, *_):
        text = self.input.text.strip()
        if not text:
            return
        app = App.get_running_app()
        app.db.save_mentor("user", text)
        response = app.progress.curriculum and __import__("core.mentor", fromlist=["LocalMentor"]).LocalMentor().answer(text)
        app.db.save_mentor("mentor", response)
        self.input.text = ""
        self.refresh()
