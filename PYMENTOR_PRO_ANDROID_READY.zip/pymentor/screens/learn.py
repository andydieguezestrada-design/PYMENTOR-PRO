from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import Screen
from kivy.uix.textinput import TextInput
from screens.base import BaseScreenMixin, NavBar, label, button, CARD, MUTED, TEXT, ACCENT


class LearnScreen(BaseScreenMixin, Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.index = 0
        self.build()

    def build(self):
        root = self.shell("APRENDER", "Ruta progresiva de Python")
        body = BoxLayout(orientation="vertical", spacing=dp(8))
        self.selector = TextInput(text="", readonly=True, multiline=False,
                                  size_hint_y=None, height=dp(44),
                                  background_color=CARD, foreground_color=TEXT,
                                  padding=dp(12))
        body.add_widget(self.selector)

        scroll = ScrollView()
        self.content = BoxLayout(orientation="vertical", spacing=dp(10), size_hint_y=None, padding=dp(6))
        self.content.bind(minimum_height=self.content.setter("height"))
        scroll.add_widget(self.content)
        body.add_widget(scroll)

        controls = BoxLayout(size_hint_y=None, height=dp(52), spacing=dp(8))
        controls.add_widget(button("← ANTERIOR", lambda *_: self.move(-1)))
        controls.add_widget(button("SIGUIENTE →", lambda *_: self.move(1), True))
        body.add_widget(controls)
        root.add_widget(body)
        root.add_widget(NavBar())
        self.add_widget(root)

    def refresh(self):
        app = App.get_running_app()
        self.lessons = app.curriculum.lessons
        if self.index >= len(self.lessons):
            self.index = len(self.lessons) - 1
        self.render()

    def move(self, delta):
        self.index = max(0, min(len(self.lessons) - 1, self.index + delta))
        self.render()

    def render(self):
        if not hasattr(self, "lessons") or not self.lessons:
            return
        app = App.get_running_app()
        lesson = self.lessons[self.index]
        self.selector.text = f"{self.index+1:02d}  /  {len(self.lessons):02d}     {lesson['title']}"
        self.content.clear_widgets()

        def add(text, size=14, color=TEXT, bold=False):
            self.content.add_widget(label(text, size, color, bold, size_hint_y=None, height=dp(max(42, text.count("\n")*20+42))))

        add(lesson["title"], 24, TEXT, True)
        add(f"OBJETIVO\n{lesson['objective']}", 14)
        add(f"EXPLICACIÓN\n{lesson['explanation']}", 14)
        add(f"EJEMPLO\n{lesson['example']}", 13, ACCENT)
        add(f"LÍNEA POR LÍNEA\n{lesson['line_by_line']}", 13)
        add(f"ERROR COMÚN\n{lesson['common_error']}", 13, MUTED)
        add(f"MINI EJERCICIO\n{lesson['exercise']}", 13)
        add(f"RETO\n{lesson['challenge']}", 13, TEXT, True)

        done = app.db.lesson_completed(lesson["id"])
        self.content.add_widget(button(
            "✓ COMPLETADA" if done else "MARCAR COMO COMPLETADA",
            lambda *_: self.complete(lesson["id"]),
            not done
        ))

    def complete(self, lesson_id):
        app = App.get_running_app()
        if app.progress.complete_lesson(lesson_id):
            self.render()
            app.refresh_all()
