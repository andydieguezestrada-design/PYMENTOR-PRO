from datetime import datetime


XP_LEVELS = [
    (0, "Python Novice"),
    (500, "Python Explorer"),
    (1200, "Python Builder"),
    (2500, "Python Developer"),
    (5000, "Python Advanced"),
    (9000, "Python Expert"),
    (15000, "Python Master"),
]


class ProgressManager:
    def __init__(self, db, curriculum):
        self.db = db
        self.curriculum = curriculum
        self.curriculum.seed(db)

    def profile(self):
        return self.db.get_profile()

    def title_for_xp(self, xp):
        title = XP_LEVELS[0][1]
        for threshold, name in XP_LEVELS:
            if xp >= threshold:
                title = name
        return title

    def next_threshold(self, xp):
        for threshold, _ in XP_LEVELS:
            if threshold > xp:
                return threshold
        return XP_LEVELS[-1][0]

    def progress_percent(self):
        stats = self.db.stats()
        return round((stats["completed_lessons"] / stats["total_lessons"]) * 100) if stats["total_lessons"] else 0

    def complete_lesson(self, lesson_id):
        if self.db.lesson_completed(lesson_id):
            return False
        self.db.set_lesson_complete(lesson_id)
        self.db.add_xp(100)
        return True

    def award(self, xp):
        self.db.add_xp(xp)

    def record_exercise(self, exercise_id, answer, score, feedback):
        self.db.execute(
            """INSERT INTO exercise_attempts(exercise_id,answer,score,feedback)
               VALUES(?,?,?,?)""",
            (exercise_id, answer, score, feedback)
        )
        if score >= 70:
            self.db.add_xp(50)

    def recommendation(self):
        stats = self.db.stats()
        if stats["completed_lessons"] < 3:
            return "Empieza por las bases: variables, tipos de datos y control de flujo."
        if stats["attempts"] < 3:
            return "Practica con ejercicios cortos antes de avanzar de módulo."
        return "Sigue con el siguiente módulo y alterna teoría con retos para consolidar lo aprendido."
