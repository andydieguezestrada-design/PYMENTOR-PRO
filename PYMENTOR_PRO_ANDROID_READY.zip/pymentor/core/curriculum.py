import json
from pathlib import Path


LEVELS = {
    "beginner": "Principiante",
    "intermediate": "Intermedio",
    "advanced": "Avanzado",
}

LEVEL_ORDER = ["beginner", "intermediate", "advanced"]


class Curriculum:
    def __init__(self):
        data_dir = Path(__file__).resolve().parent.parent / "data"
        self.lessons = json.loads((data_dir / "lessons.json").read_text(encoding="utf-8"))
        self.exercises = json.loads((data_dir / "exercises.json").read_text(encoding="utf-8"))
        self.challenges = json.loads((data_dir / "challenges.json").read_text(encoding="utf-8"))
        self.projects = json.loads((data_dir / "projects.json").read_text(encoding="utf-8"))

    def seed(self, db):
        db.seed_content(self.lessons, self.exercises, self.challenges, self.projects)

    def lesson(self, lesson_id):
        return next((x for x in self.lessons if x["id"] == lesson_id), None)

    def first_uncompleted(self, db):
        for lesson in sorted(self.lessons, key=lambda x: (LEVEL_ORDER.index(x["level"]), x["position"])):
            if not db.lesson_completed(lesson["id"]):
                return lesson
        return self.lessons[-1]

    def by_level(self, level):
        return [x for x in self.lessons if x["level"] == level]
