import re
from core.evaluator import CodeEvaluator


class LocalMentor:
    """Mentor offline basado en reglas y contenido local. Diseñado para conectar una API después."""

    TOPICS = {
        "variable": (
            "Una variable es un nombre que referencia un valor.\n\n"
            "Ejemplo:\n"
            "nombre = 'Andy'\nedad = 25\n\n"
            "Python permite cambiar el valor de una variable. El tipo depende del objeto almacenado."
        ),
        "diccionario": (
            "Un diccionario guarda pares clave: valor.\n\n"
            "usuario = {'nombre': 'Ana', 'nivel': 'intermedio'}\n"
            "print(usuario['nivel'])\n\n"
            "Es útil cuando quieres acceder a datos mediante una clave."
        ),
        "bucle": (
            "Un bucle repite instrucciones. `for` recorre elementos; `while` repite mientras una condición sea verdadera.\n\n"
            "for numero in range(3):\n    print(numero)"
        ),
        "funcion": (
            "Una función agrupa lógica reutilizable.\n\n"
            "def sumar(a, b):\n    return a + b\n\n"
            "`return` entrega un resultado a quien llamó a la función."
        ),
        "return": (
            "`return` termina la ejecución de una función y puede devolver un valor.\n\n"
            "def doble(n):\n    return n * 2\n\n"
            "Error habitual: usar print() cuando realmente necesitas devolver el resultado."
        ),
        "lista": (
            "Una lista es una colección ordenada y mutable.\n\n"
            "frutas = ['manzana', 'pera']\n"
            "frutas.append('uva')"
        ),
        "clase": (
            "Una clase define la estructura y comportamiento de objetos.\n\n"
            "class Usuario:\n    def __init__(self, nombre):\n        self.nombre = nombre"
        ),
    }

    def __init__(self):
        self.analyzer = CodeEvaluator()

    def answer(self, question):
        q = question.lower().strip()
        if not q:
            return "Escribe una pregunta sobre Python y la trabajamos paso a paso."

        if "traceback" in q or "syntaxerror" in q or "typeerror" in q or "nameerror" in q:
            return self.debug_text(question)

        if "código" in q or "codigo" in q or "def " in q or "import " in q:
            result = self.analyzer.analyze(question)
            return (
                f"{result['title']}\n\n"
                f"{result['message']}\n\n"
                "Qué ocurre: el analizador revisa la estructura sin ejecutar tu código.\n"
                "Por qué: ejecutar código arbitrario dentro de una app móvil puede ser inseguro.\n"
                "Siguiente paso: corrige lo indicado y vuelve a analizar."
            )

        for key, text in self.TOPICS.items():
            if key in q:
                return self.educational(text)

        if "qué debería estudiar" in q or "que deberia estudiar" in q or "siguiente" in q:
            return ("Te recomiendo seguir una secuencia: funciones → estructuras de datos → "
                    "excepciones → archivos/JSON → POO → testing. Después pasa a APIs y concurrencia.")

        if "ejercicio" in q or "reto" in q:
            return ("Reto recomendado: crea `calcular_promedio(numeros)`.\n"
                    "Debe recibir una lista y devolver el promedio.\n"
                    "Pista: suma los elementos y divide entre su cantidad. Evita resolverlo de memoria: intenta primero.")

        return ("Puedo ayudarte con teoría, errores, ejercicios y revisión estática de código.\n\n"
                "Prueba: «¿Qué es una variable?», «No entiendo return», "
                "«Ponme un ejercicio de funciones» o pega un fragmento de código.")

    def educational(self, base):
        return base + (
            "\n\nCómo estudiarlo:\n"
            "1. Lee la explicación.\n2. Ejecuta mentalmente el ejemplo.\n"
            "3. Cambia un dato.\n4. Resuelve un mini ejercicio.\n\n"
            "Error habitual: memorizar sintaxis sin entender qué valor entra y qué valor sale."
        )

    def debug_text(self, error):
        if "SyntaxError" in error:
            fix = "Revisa la línea indicada y busca paréntesis, comillas, dos puntos o indentación incorrectos."
        elif "NameError" in error:
            fix = "Python no encuentra ese nombre. Comprueba que la variable o función exista y esté escrita igual."
        elif "TypeError" in error:
            fix = "Estás usando un objeto con una operación incompatible con su tipo. Inspecciona los valores implicados."
        else:
            fix = "Lee la última línea del traceback: suele indicar el tipo de error y dónde ocurrió."
        return (f"Diagnóstico de error\n\n{fix}\n\n"
                "Por qué ocurre: Python detiene la ejecución cuando encuentra una operación que no puede continuar.\n"
                "Cómo evitarlo: reproduce el error con el ejemplo más pequeño posible y verifica tipos y valores.")
