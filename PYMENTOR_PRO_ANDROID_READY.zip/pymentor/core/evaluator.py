import ast
import re


class CodeEvaluator:
    """Analizador estático. No ejecuta código arbitrario del usuario."""

    FORBIDDEN = {
        "exec", "eval", "compile", "__import__", "open",
        "input", "globals", "locals", "breakpoint"
    }

    def analyze(self, source):
        if not source.strip():
            return {"ok": False, "title": "Código vacío",
                    "message": "Escribe una solución para analizarla."}
        try:
            tree = ast.parse(source)
        except SyntaxError as exc:
            line = exc.lineno or "?"
            return {
                "ok": False,
                "title": "SyntaxError",
                "message": f"Hay un error de sintaxis en la línea {line}: {exc.msg}. "
                           "Revisa paréntesis, dos puntos, indentación y comillas."
            }

        calls = [n.func.id for n in ast.walk(tree)
                 if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)]
        dangerous = [x for x in calls if x in self.FORBIDDEN]
        if dangerous:
            return {"ok": False, "title": "Código no permitido",
                    "message": "El analizador bloquea llamadas potencialmente peligrosas: "
                               + ", ".join(sorted(set(dangerous))) + "."}

        names = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)}
        functions = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
        suggestions = []
        if functions and not any(isinstance(n, ast.Return) for n in ast.walk(tree)):
            suggestions.append("Tu función no contiene return; comprueba si debe devolver un valor.")
        if "sorted" in names:
            suggestions.append("Si el reto prohíbe sorted(), busca una solución basada en recorridos.")
        if not suggestions:
            suggestions.append("La sintaxis es válida y no se detectaron patrones bloqueados.")
        return {"ok": True, "title": "Análisis completado",
                "message": "\n".join("• " + s for s in suggestions)}


class ExerciseEvaluator:
    def evaluate(self, exercise, answer):
        required = exercise.get("required", [])
        missing = [token for token in required if token not in answer]
        if missing:
            return 35, "Tu solución todavía necesita: " + ", ".join(missing)
        return 100, "Buen trabajo. Has incluido los elementos principales del ejercicio."
