import json
import os
import sqlite3
from datetime import date


class Database:
    def __init__(self, path=None):
        if path is None:
            try:
                from kivy.app import App
                base = App.get_running_app().user_data_dir
            except Exception:
                base = os.path.join(os.getcwd(), ".pymentor_data")
            os.makedirs(base, exist_ok=True)
            path = os.path.join(base, "pymentor.db")
        self.path = path
        self.conn = sqlite3.connect(self.path)
        self.conn.row_factory = sqlite3.Row
        self._create_schema()

    def _create_schema(self):
        self.conn.executescript("""
        PRAGMA foreign_keys = ON;

        CREATE TABLE IF NOT EXISTS profile (
            id INTEGER PRIMARY KEY CHECK(id=1),
            name TEXT DEFAULT 'Python Learner',
            level TEXT DEFAULT 'beginner',
            goal TEXT DEFAULT 'learn_from_zero',
            xp INTEGER DEFAULT 0,
            streak INTEGER DEFAULT 0,
            last_study_date TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS lessons (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            level TEXT NOT NULL,
            position INTEGER NOT NULL,
            content_json TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS lesson_progress (
            lesson_id TEXT PRIMARY KEY,
            completed INTEGER DEFAULT 0,
            score INTEGER DEFAULT 0,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(lesson_id) REFERENCES lessons(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS exercise_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exercise_id TEXT NOT NULL,
            answer TEXT,
            score INTEGER DEFAULT 0,
            feedback TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS challenges (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            difficulty TEXT NOT NULL,
            xp INTEGER NOT NULL,
            content_json TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            level TEXT NOT NULL,
            content_json TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS mentor_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        """)
        if not self.fetchone("SELECT id FROM profile WHERE id=1"):
            self.execute(
                "INSERT INTO profile(id) VALUES(1)"
            )

    def execute(self, sql, params=()):
        cur = self.conn.execute(sql, params)
        self.conn.commit()
        return cur

    def executemany(self, sql, rows):
        self.conn.executemany(sql, rows)
        self.conn.commit()

    def fetchone(self, sql, params=()):
        return self.conn.execute(sql, params).fetchone()

    def fetchall(self, sql, params=()):
        return self.conn.execute(sql, params).fetchall()

    def seed_content(self, lessons, exercises, challenges, projects):
        for lesson in lessons:
            self.execute(
                """INSERT OR IGNORE INTO lessons(id,title,level,position,content_json)
                   VALUES(?,?,?,?,?)""",
                (lesson["id"], lesson["title"], lesson["level"],
                 lesson["position"], json.dumps(lesson, ensure_ascii=False))
            )
        for challenge in challenges:
            self.execute(
                """INSERT OR IGNORE INTO challenges(id,title,difficulty,xp,content_json)
                   VALUES(?,?,?,?,?)""",
                (challenge["id"], challenge["title"], challenge["difficulty"],
                 challenge["xp"], json.dumps(challenge, ensure_ascii=False))
            )
        for project in projects:
            self.execute(
                """INSERT OR IGNORE INTO projects(id,title,level,content_json)
                   VALUES(?,?,?,?)""",
                (project["id"], project["title"], project["level"],
                 json.dumps(project, ensure_ascii=False))
            )
        # Exercises are intentionally stored as attempts only; definitions live in JSON.

    def get_profile(self):
        return self.fetchone("SELECT * FROM profile WHERE id=1")

    def update_profile(self, **fields):
        allowed = {"name", "level", "goal", "xp", "streak", "last_study_date"}
        clean = {k: v for k, v in fields.items() if k in allowed}
        if not clean:
            return
        parts = ", ".join(f"{k}=?" for k in clean)
        self.execute(f"UPDATE profile SET {parts} WHERE id=1", tuple(clean.values()))

    def add_xp(self, amount):
        self.execute("UPDATE profile SET xp=xp+? WHERE id=1", (int(amount),))
        self.touch_study_day()

    def touch_study_day(self):
        today = date.today().isoformat()
        profile = self.get_profile()
        last = profile["last_study_date"]
        streak = profile["streak"]
        if last == today:
            return
        if last:
            from datetime import date as D
            delta = (D.fromisoformat(today) - D.fromisoformat(last)).days
            streak = streak + 1 if delta == 1 else 1
        else:
            streak = 1
        self.update_profile(streak=streak, last_study_date=today)

    def set_lesson_complete(self, lesson_id, score=100):
        self.execute(
            """INSERT INTO lesson_progress(lesson_id,completed,score)
               VALUES(?,?,?)
               ON CONFLICT(lesson_id) DO UPDATE SET completed=excluded.completed,
               score=excluded.score, updated_at=CURRENT_TIMESTAMP""",
            (lesson_id, 1, score)
        )

    def lesson_completed(self, lesson_id):
        row = self.fetchone(
            "SELECT completed FROM lesson_progress WHERE lesson_id=?", (lesson_id,)
        )
        return bool(row and row["completed"])

    def stats(self):
        total = self.fetchone("SELECT COUNT(*) c FROM lessons")["c"]
        done = self.fetchone(
            "SELECT COUNT(*) c FROM lesson_progress WHERE completed=1"
        )["c"]
        attempts = self.fetchone("SELECT COUNT(*) c FROM exercise_attempts")["c"]
        challenges = self.fetchone(
            "SELECT COUNT(*) c FROM exercise_attempts WHERE exercise_id LIKE 'challenge:%'"
        )["c"]
        return {"total_lessons": total, "completed_lessons": done,
                "attempts": attempts, "challenge_attempts": challenges}

    def mentor_messages(self, limit=30):
        return self.fetchall(
            "SELECT role,message,created_at FROM mentor_history ORDER BY id DESC LIMIT ?",
            (limit,)
        )

    def save_mentor(self, role, message):
        self.execute(
            "INSERT INTO mentor_history(role,message) VALUES(?,?)",
            (role, message)
        )

    def clear_history(self):
        self.execute("DELETE FROM mentor_history")

    def close(self):
        self.conn.close()
