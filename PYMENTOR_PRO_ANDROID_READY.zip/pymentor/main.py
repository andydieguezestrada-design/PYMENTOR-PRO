from kivy.config import Config
Config.set("graphics", "minimum_width", "360")
Config.set("graphics", "minimum_height", "640")

from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.properties import StringProperty, NumericProperty
from kivy.uix.screenmanager import ScreenManager, FadeTransition

from database.database import Database
from core.curriculum import Curriculum
from core.progress import ProgressManager
from screens.home import HomeScreen
from screens.learn import LearnScreen
from screens.mentor import MentorScreen
from screens.challenges import ChallengesScreen
from screens.progress import ProgressScreen
from screens.settings import SettingsScreen


class PyMentorApp(App):
    title = "PYMENTOR PRO"

    def build(self):
        self.db = Database()
        self.curriculum = Curriculum()
        self.progress = ProgressManager(self.db, self.curriculum)

        sm = ScreenManager(transition=FadeTransition(duration=0.15))
        sm.add_widget(HomeScreen(name="home"))
        sm.add_widget(LearnScreen(name="learn"))
        sm.add_widget(MentorScreen(name="mentor"))
        sm.add_widget(ChallengesScreen(name="challenges"))
        sm.add_widget(ProgressScreen(name="progress"))
        sm.add_widget(SettingsScreen(name="settings"))
        self.sm = sm
        Clock.schedule_once(lambda *_: self.refresh_all(), 0)
        return sm

    def go(self, screen_name):
        self.sm.current = screen_name
        self.refresh_all()

    def refresh_all(self):
        for screen in self.sm.screens:
            if hasattr(screen, "refresh"):
                screen.refresh()

    def on_stop(self):
        self.db.close()


if __name__ == "__main__":
    PyMentorApp().run()
