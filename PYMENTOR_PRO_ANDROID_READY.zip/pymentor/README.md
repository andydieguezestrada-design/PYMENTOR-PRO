# PYMENTOR PRO

MVP funcional de una aplicación Android educativa de Python construida con Python 3 + Kivy + SQLite.

## Características

- Ruta de aprendizaje de principiante a avanzado.
- 61+ lecciones con objetivos, explicación, ejemplo, línea por línea, errores y retos.
- Mentor offline basado en reglas/contenido local.
- Diagnóstico estático de código con `ast`.
- No ejecuta código arbitrario del usuario.
- Retos diarios con XP.
- Dashboard de progreso, racha y niveles.
- SQLite persistente.
- Proyectos progresivos.
- Arquitectura preparada para incorporar un proveedor de IA externo.
- Configuración de nivel y objetivo.

## Requisitos

Para Android se recomienda compilar en Linux/WSL. Instala Python 3, Java/JDK compatible con Buildozer y las dependencias de Buildozer.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Para probar en escritorio:

```bash
python main.py
```

## APK debug

```bash
buildozer android debug
```

La primera compilación puede tardar bastante porque descarga el toolchain Android.

## Release

Configura primero un keystore de firma y después ejecuta:

```bash
buildozer android release
```

El artefacto queda normalmente dentro de `bin/`. La firma final y gestión de claves debe hacerse siguiendo las prácticas de seguridad de Android.

## Estructura

```text
pymentor/
├── main.py
├── buildozer.spec
├── requirements.txt
├── README.md
├── screens/
│   ├── base.py
│   ├── home.py
│   ├── learn.py
│   ├── mentor.py
│   ├── challenges.py
│   ├── progress.py
│   └── settings.py
├── core/
│   ├── curriculum.py
│   ├── evaluator.py
│   ├── mentor.py
│   └── progress.py
├── database/
│   └── database.py
└── data/
    ├── lessons.json
    ├── exercises.json
    ├── challenges.json
    └── projects.json
```

## Seguridad del editor

El botón de análisis usa AST y reglas de seguridad. No se usa `exec()`/`eval()` para ejecutar código arbitrario dentro de la app. Esto es deliberado: una app móvil educativa no debería ejecutar sin aislamiento código introducido por el usuario.

Para una futura ejecución real, se recomienda un sandbox independiente (por ejemplo, backend aislado o un intérprete restringido diseñado específicamente para ejercicios), con límites de CPU, memoria, tiempo, filesystem y red.

## Cómo añadir lecciones

Edita `data/lessons.json` y agrega un objeto con:

- `id`
- `title`
- `level`
- `position`
- `objective`
- `explanation`
- `example`
- `line_by_line`
- `common_error`
- `exercise`
- `challenge`

La base local usa `INSERT OR IGNORE`, por lo que para actualizar contenido existente durante desarrollo puede ser necesario borrar la base de pruebas o implementar migraciones/versionado.

## Cómo añadir ejercicios

Añade objetos a `data/exercises.json` con `id`, `title`, `difficulty`, `prompt`, `required` y `solution`.

## Cómo añadir proyectos

Añade objetos a `data/projects.json` con nivel, conceptos, objetivos, requisitos, pasos, código inicial, solución y extras.

## Conectar una IA externa

Mantén el flujo:

`UI -> MentorService -> Provider`

y crea un proveedor separado, por ejemplo:

```text
core/
  mentor.py
  providers/
    local.py
    remote.py
```

Nunca introduzcas una API key dentro del APK. Usa un backend propio o almacenamiento seguro apropiado. La UI no debe conocer detalles del proveedor.

## Solución de problemas

### Buildozer falla al instalar dependencias
Usa un entorno Linux/WSL limpio, actualiza pip y revisa la versión de Java/SDK/NDK recomendada por la versión de Buildozer/p4a instalada.

### La app no encuentra JSON
Comprueba que `data/*.json` estén incluidos por `source.include_exts` y que el proyecto se compile desde la raíz.

### Cambié una lección y no aparece
Durante desarrollo, elimina la base local de la app para volver a sembrar el contenido. En producción, usa migraciones/versionado de contenido.

## Estado del MVP

La base es funcional y escalable, pero para un producto comercial todavía conviene añadir:

- Material visual y branding final.
- Editor con resaltado más completo.
- Sistema de cuentas/sincronización opcional.
- Tests automatizados de la aplicación.
- Telemetría respetuosa con la privacidad.
- Sandbox de ejecución real.
- Backend seguro para IA.
- Internacionalización.
- Accesibilidad auditada.
- Firma, CI/CD y distribución Play Store.


## Compilación desde GitHub Actions

El proyecto incluye `.github/workflows/build-apk.yml`. Desde GitHub puedes abrir
**Actions → PYMENTOR PRO - Android APK → Run workflow**. Al terminar, el APK
aparecerá como artefacto descargable de esa ejecución.

La configuración está preparada para Android con target API 35, mínimo API 24,
NDK 28c y arquitecturas `arm64-v8a` y `armeabi-v7a`.
